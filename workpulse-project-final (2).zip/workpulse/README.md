# 🚀 WorkPulse — AI-Powered Employee Productivity System

> Hackathon 2026 Project | Full-Stack: React + Node.js + MongoDB + JWT + Electron

---

## 📁 Project Structure

```
workpulse/
├── backend/          ← Node.js + Express + MongoDB API
├── frontend/         ← React + Tailwind CSS
└── desktop/          ← Electron.js desktop tracking app
```

---

## ⚡ Quick Start (3 terminals)

### 1. Backend Setup

```bash
cd backend
npm install
cp .env.example .env        # Edit MONGO_URI and JWT_SECRET
npm run seed                # Populate demo data (optional)
npm run dev                 # Starts on http://localhost:5000
```

### 2. Frontend Setup

```bash
cd frontend
npm install
npm start                   # Starts on http://localhost:3000
```

### 3. Desktop App (optional)

```bash
cd desktop
npm install
npm start                   # Electron window opens
```

---

## 🔧 Environment Setup (.env)

Edit `backend/.env`:

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/workpulse   # Local MongoDB
# OR
MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/workpulse  # Atlas

JWT_SECRET=change_this_to_something_long_and_random
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:3000
```

---

## 🗄️ MongoDB Options

### Option A — Local MongoDB
1. Install: https://www.mongodb.com/try/download/community
2. Start: `mongod`
3. Use URI: `mongodb://localhost:27017/workpulse`

### Option B — MongoDB Atlas (Cloud, Free Tier)
1. Go to: https://cloud.mongodb.com
2. Create free cluster
3. Get connection string → paste in `MONGO_URI`

---

## 🌱 Demo Seed Data

After running `npm run seed` from backend/:

| Role     | Email                      | Password     |
|----------|---------------------------|--------------|
| Manager  | manager@workpulse.com     | password123  |
| Employee | sarah@workpulse.com       | password123  |
| Employee | rahul@workpulse.com       | password123  |

---

## 🔌 API Endpoints

### Auth
| Method | Route               | Description         | Access  |
|--------|---------------------|---------------------|---------|
| POST   | /api/auth/register  | Register user       | Public  |
| POST   | /api/auth/login     | Login + get token   | Public  |
| GET    | /api/auth/me        | Get current user    | Private |
| PUT    | /api/auth/password  | Update password     | Private |

### Activity
| Method | Route                      | Description            | Access          |
|--------|----------------------------|------------------------|-----------------|
| POST   | /api/activity              | Log activity event     | Private         |
| GET    | /api/activity/me           | My activities today    | Private         |
| GET    | /api/activity/hourly/:id   | Hourly breakdown chart | Private         |
| GET    | /api/activity/team         | All team activity      | Manager/Admin   |

### Analytics
| Method | Route                      | Description            | Access          |
|--------|----------------------------|------------------------|-----------------|
| GET    | /api/analytics/me          | My productivity 7 days | Private         |
| GET    | /api/analytics/team        | Team overview + alerts | Manager/Admin   |
| GET    | /api/analytics/heatmap/:id | Weekly heatmap data    | Private         |
| GET    | /api/analytics/summary     | Full team summary      | Manager/Admin   |

### Projects
| Method | Route              | Description        | Access        |
|--------|--------------------|--------------------|---------------|
| GET    | /api/projects      | List projects      | Private       |
| POST   | /api/projects      | Create project     | Manager/Admin |
| PUT    | /api/projects/:id  | Update project     | Manager/Admin |
| DELETE | /api/projects/:id  | Delete project     | Manager/Admin |

---

## 🏗️ Tech Stack

| Layer       | Technology                        |
|-------------|-----------------------------------|
| Frontend    | React 18, Tailwind CSS, Chart.js  |
| Backend     | Node.js, Express.js               |
| Database    | MongoDB + Mongoose                |
| Auth        | JWT (jsonwebtoken + bcryptjs)     |
| Desktop App | Electron.js                       |
| Charts      | Chart.js, react-chartjs-2         |
| Arch        | Microservices-inspired, REST API  |

---

## 🔒 Security Features
- Passwords hashed with bcryptjs (salt rounds: 10)
- JWT tokens with expiry
- Role-based access control (employee / manager / admin)
- Rate limiting (200 req / 15 min)
- CORS restricted to frontend URL
- Private activity never sent to server

---

## 🤖 AI Features (Implemented)
- **Productivity Score**: Active vs idle time ratio (0–100)
- **Burnout Detection**: Flags if active > 10h/day
- **Anomaly Flagging**: Detects unusual patterns (stored in DB)
- **App Categorization**: Auto-categorizes apps in Electron tracker

---

## 📦 Deployment

### Backend (Railway / Render / Heroku)
```bash
cd backend
# Set env vars in dashboard, then:
npm start
```

### Frontend (Vercel / Netlify)
```bash
cd frontend
npm run build
# Deploy /build folder
```

### Desktop App (Electron Builder)
```bash
cd desktop
npm run build
# Outputs installer to /dist
```
